These scripts use all cores on your system.
The CSVs can be deleted they're just previous run history.


Run in order.

python part1_manual_trigram.py

python part2_bayesian.py

python part3_knn_parallel.py